export const APP_ROUTES = {
  HOME: "home",
  UPCOMING_MOVIES: "upComingMovies",
  MOVIES: "movies",
};
