import { useEffect } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { APP_ROUTES } from "./Routes";
import Home from "./components/home/Home";
import UpcomingMovies from "./components/upcomingMovies/UpcomingMovies";
import Page404 from "./components/errorMessage/page404";
import Movie from "./components/movies/Movie";
import "./App.scss";

import {
  getMoviesGenre,
  getTrendingMovies,
  getUpComingMovies,
} from "./apis/MovieApi";
import { useDispatch } from "react-redux";
import {
  addMoviesGenre,
  addTrendingMovies,
  addUpcomingMovies,
} from "./redux/movieSlice";
import Header from "./components/header/Header";

function App() {
  const dispatch = useDispatch();
  useEffect(() => {
    const fetchData = async () => {
      const trendingMovies = await getTrendingMovies();
      const genre = await getMoviesGenre();
      const upcomingMovies = await getUpComingMovies();
      dispatch(addTrendingMovies(trendingMovies));
      dispatch(addMoviesGenre(genre));
      dispatch(addUpcomingMovies(upcomingMovies));

      return;
    };
    fetchData().catch(console.error);
    console.log("first");
  }, [dispatch]);

  return (
    <div className="app">
      <Header></Header>
      <Routes>
        <Route
          path="/"
          element={<Navigate to={`/${APP_ROUTES.HOME}`} replace={true} />}
        />
        <Route path={`/${APP_ROUTES.HOME}`} element={<Home />} />
        <Route path={`${APP_ROUTES.MOVIE}/:id`} element={<Movie />} />
        <Route
          path={`/${APP_ROUTES.UPCOMING_MOVIES}`}
          element={<UpcomingMovies />}
        />
        <Route path="*" element={<Page404 />} />
      </Routes>
    </div>
  );
}

export default App;
