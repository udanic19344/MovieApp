import React from "react";
import "./Header.scss";
import { useNavigate } from "react-router-dom";
import { APP_ROUTES } from "../../Routes";

const Header = () => {
  const navigate = useNavigate();

  const changeRoute = (route) => {
    navigate(`/${route}`);
  };
  return (
    <div className="header">
      <ul className="nav-links">
        <li onClick={() => changeRoute(APP_ROUTES.HOME)} className="home">
          Home
        </li>
        <li
          onClick={() => changeRoute(APP_ROUTES.UPCOMING_MOVIES)}
          className="upcoming"
        >
          UpComing Movies
        </li>
      </ul>
    </div>
  );
};

export default Header;
