import React from "react";
import "./page404.scss";

const Page404 = () => {
  return (
    <div className="not_found">
      <h1 className="error">404</h1>
      <p className="message_OPPS">OPPS! </p>
      <p className="message">The page you requested could not be found</p>
    </div>
  );
};

export default Page404;
